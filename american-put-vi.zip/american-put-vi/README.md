# American Options as Variational Inequalities

Pricing the American put as a **parabolic variational inequality** with three methods: a penalty method with finite differences, a projection method (projected SOR) and a physics-informed neural network (PINN). Each is checked against independent reference prices.

This repository is the computational part of my BSc thesis at the Athens University of Economics and Business (Department of Statistics, 2025), *Pricing the Risk of Decision Using Variational Inequalities: An American Type Derivatives Example*, supervised by Professor A. N. Yannacopoulos. The theory is in the thesis, and this repository replaces its numerical results chapter.

📄 **Thesis (Chapters 1–5, revised):** [`thesis/Dallas_BSc_thesis_variational_inequalities.pdf`](thesis/Dallas_BSc_thesis_variational_inequalities.pdf)

<p align="center">
  <img src="results/option_value.png" width="900" alt="American put value and pricing error of the three methods">
</p>

## Where things are

| Thesis | Topic | In this repository |
|---|---|---|
| Ch. 1 | Elliptic VIs: Lions–Stampacchia, penalization, regularity, free boundary | (theory) |
| Ch. 2 | Parabolic VIs, Bochner spaces, viscosity solutions | (theory) |
| Ch. 3 | The American put as a parabolic VI | the problem solved below |
| Ch. 4 | Penalization + finite differences; Minty, projection, PSOR | [`pvi/finite_difference.py`](pvi/finite_difference.py) |
| Ch. 5 | Physics-informed neural networks for the PVI | [`pvi/pinn.py`](pvi/pinn.py) |
| (Results) | Comparison against reference prices | [`benchmark.py`](benchmark.py), [`results/`](results/) |

## The problem

An American put with strike $K$ can be exercised at any time before maturity $T$. Its value $V(q, S)$, as a function of time to expiry $q = T - t$ and stock price $S$, solves the **parabolic variational inequality** (thesis, eq. 3.14):

```math
\min\Big\{ \partial_q V + A V,\; V - \psi \Big\} = 0,
\qquad
A V = -\tfrac12\sigma^2 S^2\, \partial_{SS} V - r S\, \partial_S V + r V,
\qquad
\psi(S) = (K - S)^+ ,
```

with $V(0, S) = \psi(S)$, $V(q, 0) = K$ and $V(q, S_{\max}) = 0$.

At every point, either the Black–Scholes equation holds (continuation region: keep the option) or $V = \psi$ (exercise region: exercise now). The two regions are separated by the unknown **early-exercise boundary** $S^\ast(q)$. Because the value function is only $C^1$, not $C^2$, across that boundary, it is not a classical solution of any single PDE (Section 3.2.3), which is why the problem is posed as a variational inequality.

**Parameters** (as in the thesis): $K = 50$, $r = 5\%$, $\sigma = 20\%$, $T = 1$ year, $S_{\max} = 100$.

## Methods

| Method | How the constraint $V \ge \psi$ is enforced | Implementation |
|---|---|---|
| **Penalty FD** | Adds $\tfrac{1}{\varepsilon}\min(V - \psi, 0)$ to the PDE ($\varepsilon = 10^{-6}$). The penalty is treated implicitly and solved by Newton/policy iteration each step. | Crank–Nicolson with Rannacher start-up, tridiagonal solves |
| **Projected SOR** | Projection $P_K(z) = \max(z, \psi)$ applied node by node inside an SOR sweep (Cryer, 1971). This is the efficient form of the fixed point $V = P_K(V - \alpha\,\cdot\text{residual})$ from Minty's reformulation. | Same discretisation; Young's optimal $\omega$ |
| **PINN** | The loss is the residual of the VI itself, $\lVert\min(-\mathcal{B}[u],\, u - \psi)\rVert^2$, plus terminal and boundary terms. | 4 × 64 tanh network, output layer enforcing $u(0,t)=K$, Adam, 20 000 iterations |
| **Reference** | QuantLib's finite-difference engine on a 4000 × 4000 grid. Independent of this code, and agrees with a fine-grid PSOR solution to $10^{-4}$. | `pvi/reference.py` |

## Results

Option values one year before expiry (`python benchmark.py`):

| $S_0$ | Reference | European | Penalty FD | PSOR | PINN | PINN, thesis loss |
|---|---|---|---|---|---|---|
| 30 | **20.0000** | 17.5887 | 20.0000 | 20.0000 | 19.9943 | 19.2997 |
| 40 | **10.0000** | 8.4912 | 10.0000 | 10.0000 | 9.9706 | 9.5624 |
| 45 | **5.7462** | 5.1071 | 5.7462 | 5.7462 | 5.7432 | 5.6684 |
| 50 | **3.0451** | 2.7868 | 3.0450 | 3.0450 | 3.0593 | 3.0499 |
| 55 | **1.4932** | 1.3929 | 1.4931 | 1.4931 | 1.5138 | 1.5053 |
| 60 | **0.6835** | 0.6460 | 0.6835 | 0.6835 | 0.7064 | 0.6992 |
| 70 | **0.1216** | 0.1168 | 0.1216 | 0.1216 | 0.1410 | 0.1273 |
| **max error** | | | **0.0001** | **0.0001** | **0.029** | **0.70** |
| **runtime** | | | **0.09 s** | **0.34 s** | **13 min** | **13 min** |

Grid methods use $M = N = 800$. Runtimes are on a laptop-class CPU. The exercise boundary one year before expiry is $S^\ast \approx 40.4$.

### 1. The two grid methods are accurate and fast

Penalty FD and PSOR agree with the reference to $10^{-4}$ at every price. Their error falls about fourfold each time the grid is doubled, until it reaches the accuracy of the reference itself. The penalty method is the faster of the two on fine grids (0.09 s against 0.34 s at $M = 800$), because each Newton step is a direct tridiagonal solve, while PSOR needs more sweeps as the grid is refined. Both trace the exercise boundary exactly.

<p align="center">
  <img src="results/grid_convergence.png" width="820" alt="Error and runtime against grid size">
</p>

### 2. The PINN works, but only with the right loss, and it is slow

* **With the VI-residual loss** the network prices to within about 0.03 everywhere: within 0.03 of the reference at the money and close to the payoff deep in the money.
* **With the loss as originally written in the thesis**, which penalizes the full Black–Scholes residual $\lVert\mathcal{B}[u]\rVert^2$, the network prices *below the payoff* deep in the money: 19.30 at $S = 30$, where exercising immediately gives 20. That term forces the PDE to hold where it shouldn't, and breaks the constraint $u \ge \psi$.
* **An intermediate version** (one-sided PDE term with the product complementarity penalty $\lVert(u - \psi)\,\mathcal{B}[u]\rVert^2$, available as `loss="corrected"`) over-prices by up to 0.57. The product is tiny whenever both factors are small, so it barely penalizes an over-priced solution.

Chapter 5 of the revised thesis explains these choices. The PINN is still thousands of times slower than the grid methods on this problem (13 minutes against a fraction of a second), and less accurate. Its advantage, being mesh-free, only pays off in high dimensions, where grids are impossible.

### 3. The exercise boundary is much harder for the PINN than the price

<p align="center">
  <img src="results/exercise_boundary.png" width="640" alt="Early-exercise boundary">
</p>

The grid methods recover $S^\ast(q)$ exactly. The PINN's boundary is about 2 units too high, even though its prices are accurate to 0.03. This is not a bug: near the boundary the option value differs from the payoff only quadratically, $V - \psi \approx \tfrac12\Gamma\,(S - S^\ast)^2$, so a tiny error in value moves the apparent boundary a long way. The network's boundary is read off the VI itself, as the set where $u - \psi < -\mathcal{B}[u]$, with no tolerance to tune.

## About the thesis PDF

The PDF contains Chapters 1–5 and Appendix A.1 of the thesis, revised in 2026. While building this repository I checked the thesis against the working code and corrected the errors I found. The main ones:

* **Sign of the Black–Scholes operator (Ch. 3–4).** It was written as $A V = +\tfrac12\sigma^2S^2V_{SS} + \dots$ inside $\partial_q V + AV \ge 0$, which makes the equation run backwards in time; in the submitted version, eq. (3.20) contradicted eq. (3.12). The operator now carries the sign convention of Chapters 1–2, and the complementarity form (3.9) is fixed accordingly.
* **The PINN loss (Ch. 5)** was replaced by the VI residual, as explained above.
* **Numerical schemes (Ch. 4).** The penalty is now treated implicitly; explicit treatment is unstable for small $\varepsilon$. A description of projected SOR was added.
* **Theory (Ch. 1–2, App. A.1):**
  * corrected statement of the Aubin–Lions lemma;
  * a correct hemicontinuous-but-discontinuous example;
  * a well-defined coercivity condition and consistent penalty function $\beta(s) = \min(s,0)$;
  * the missing uniform penalty bound in the $H^2$-regularity proof;
  * a complete proof of the Lions–Stampacchia theorem (Galerkin approximation and Minty's lemma instead of an infinite-dimensional Brouwer argument).
* **Cross-references:** all "??" and stale references were fixed.

The original Chapter 6 (Results) is not included. Its reference values were wrong: for example, it reported $u(50) \approx 4$ and an exercise boundary of 35–37, whereas the correct values are 3.045 and 40.4. This repository replaces it.

## Running

```bash
pip install -r requirements.txt
python benchmark.py               # tables and figures (uses the trained PINNs in results/)
python benchmark.py --retrain     # also retrain both PINNs (~13 min each on a CPU)
python benchmark.py --skip-pinn   # grid methods only
pytest -q                         # tests
```

```python
from pvi.finite_difference import penalty_fd, price_at
res = penalty_fd(K=50, r=0.05, sigma=0.2, T=1.0, S_max=100, M=800, N=800)
price_at(res, 50)        # 3.0450
res["boundary"][-1]      # exercise boundary one year before expiry, ~40.4
```

```
pvi/finite_difference.py   penalty method and projected SOR (Crank–Nicolson, Rannacher start-up)
pvi/pinn.py                physics-informed neural network (three loss variants)
pvi/reference.py           QuantLib reference prices
benchmark.py               runs everything, writes results/
results/                   figures, CSV tables, trained network weights
thesis/                    thesis PDF (Chapters 1–5, revised)
tests/                     pytest suite
```

## References

* Yannacopoulos, A. N., & Tsekrekos, A. E. (2020). *Variational Inequalities and Applications in Finance*. Springer.
* Kinderlehrer, D., & Stampacchia, G. (1980). *An Introduction to Variational Inequalities and Their Applications*. Academic Press.
* Cryer, C. W. (1971). The solution of a quadratic programming problem using systematic overrelaxation. *SIAM Journal on Control*, 9(3), 385–392.
* Forsyth, P. A., & Vetzal, K. R. (2002). Quadratic convergence for valuing American options using a penalty method. *SIAM Journal on Scientific Computing*, 23(6), 2095–2122.
* Raissi, M., Perdikaris, P., & Karniadakis, G. E. (2019). Physics-informed neural networks. *Journal of Computational Physics*, 378, 686–707.
* Sirignano, J., & Spiliopoulos, K. (2018). DGM: A deep learning algorithm for solving partial differential equations. *Journal of Computational Physics*, 375, 1339–1364.

## License

Code: MIT, see [LICENSE](LICENSE). The thesis PDF remains © the author.
